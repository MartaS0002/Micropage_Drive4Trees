Mit unserer App ermöglichen wir nicht nur Mitfahrgelegenheiten durch den
gesamten Schwarzwald, sondern tun dabei auch noch etwas Gutes für unsere
Umwelt! Denn durch das Sammeln von sogenannten Umweltcoins, die pro Fahrt
oder durch andere Challenges erworben werden, pflanzt Drive4trees für
deinen Einsatz Nadelbäume im gesamten Schwarzwald.
Für den Umweltschutz, für den Erhalt von Bäumen im Schwarzwald, für DICH!
